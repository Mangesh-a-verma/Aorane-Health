# Design System Strategy: Luminous Precision

## 1. Overview & Creative North Star
The design system is guided by a Creative North Star titled **"Luminous Precision."** In the high-stakes world of Indian corporate health-tech, the UI must balance clinical authority with a sense of breathable, futuristic optimism. 

This system rejects the "standard dashboard" aesthetic of dense tables and rigid borders. Instead, it adopts an **Editorial Spatial** layout. We utilize intentional asymmetry, overlapping translucent layers, and high-contrast typography scales to guide the user’s eye. The goal is to make a complex CRM feel like a premium, curated experience where data doesn't just sit on a screen—it floats in a structured, airy environment.

---

## 2. Colors & Surface Philosophy
The palette is a sophisticated blend of heritage and future. We use Deep Indian Saffron for action and energy, balanced by a calming Deep Teal for stability and health.

### Surface Hierarchy & Nesting
We define depth through **Tonal Layering** rather than structural lines.
- **The "No-Line" Rule:** Standard 1px solid borders for sectioning are prohibited. Boundaries must be defined through background shifts. For example, a `surface-container-low` (#f2f4f7) sidebar sits against a `surface` (#f7f9fc) workspace.
- **The "Glass & Gradient" Rule:** Floating elements (modals, popovers, navigation) must use Glassmorphism. Utilize `surface-container-lowest` (#ffffff) at 80% opacity with a `20px backdrop-blur`. 
- **Signature Textures:** Use subtle linear gradients for primary CTAs, transitioning from `primary` (#8f4e00) to `primary_container` (#ff9933). This adds a "soul" to the interface that flat colors cannot replicate.

### Core Token Reference
- **Background:** `surface` (#f7f9fc)
- **Primary (Saffron):** `primary` (#8f4e00) | `on_primary_container` (#693800)
- **Secondary (Teal):** `secondary` (#006a6a) | `secondary_container` (#90efef)
- **Tertiary (Indigo):** `tertiary` (#4d44e3)
- **Neutral Transitions:** `surface_container_low` (#f2f4f7) to `surface_container_highest` (#e0e3e6)

---

## 3. Typography
Typography is our primary tool for establishing an "Editorial" feel. By utilizing **Geist Sans**, we achieve a monospaced-influenced precision that feels engineered yet accessible.

- **Display Scale (The Hero):** Use `display-lg` (3.5rem) for high-level health metrics or welcome states. Use tight letter-spacing (-0.02em) to create a "locked-in" premium feel.
- **Headline Scale (The Statement):** `headline-md` (1.75rem) should be used for card titles to create an authoritative hierarchy.
- **The Functional Body:** `body-md` (0.875rem) is the workhorse. It must remain clean with generous line-height (1.6) to ensure readability during long sessions of data entry.
- **Micro-Copy:** `label-sm` (0.6875rem) in all-caps with increased letter-spacing (+0.05em) is used for metadata and table headers to provide a "technical" look without adding visual weight.

---

## 4. Elevation & Depth
Depth in this system is inspired by Apple Vision Pro’s translucency—light passes through surfaces, creating a sense of physical space.

- **The Layering Principle:** Depth is achieved by "stacking" surface tiers. Place a `surface-container-lowest` card on a `surface-container-low` section. This creates a soft, natural lift.
- **Ambient Shadows:** When a floating effect is required (e.g., a hovering dashboard widget), use a shadow with a 32px blur and 4% opacity. The shadow color should be a tinted version of `on-surface` (#191c1e), never pure black.
- **The "Ghost Border":** If a container requires a boundary for accessibility, use the `outline_variant` token at 15% opacity. This "Ghost Border" provides containment without disrupting the luminous flow of the page.
- **Neumorphic Accents:** For interactive elements like toggles or inset cards, use a very subtle neumorphic shadow: a 1px white highlight on the top-left and a 1px `surface_container_high` shadow on the bottom-right.

---

## 5. Components

### Cards & Containers
Cards must never use divider lines. Separate content using `surface_container` shifts or `xl` (1.5rem) vertical padding. Use `lg` (1rem) corner radius as the standard.
- **Style:** `surface-container-lowest` with 80% opacity and `backdrop-filter: blur(12px)`.

### Buttons
- **Primary:** Gradient from `primary` to `primary_container`. Shape: `full` (pill). Text: `on_primary` (#ffffff).
- **Secondary:** Transparent background with a `Ghost Border`. Text: `secondary` (#006a6a).
- **Interactive State:** On hover, the button should "lift" using a subtle 1.02x scale transformation and an increased shadow blur.

### Input Fields
Inputs should feel "carved" into the interface.
- **State:** Use `surface_container_low` for the base. On focus, transition to `surface_container_lowest` with a 1px `primary` Ghost Border and a soft Saffron outer glow (4px blur, 10% opacity).

### Data Visualization (The Indigo Accent)
Health trends and CRM analytics use `tertiary` (#4d44e3). Use "Liquid" line charts with soft gradients filling the area beneath the curve, transitioning from `tertiary_container` to transparent.

---

## 6. Do’s and Don’ts

### Do:
- **Do** use overlapping elements. A glass card should slightly overlap a background gradient or image to show off the backdrop-blur effect.
- **Do** lean into white space. If a layout feels "busy," increase the padding rather than adding a divider.
- **Do** use `display-sm` typography for numbers. Data is the star; let the digits be large and bold.

### Don’t:
- **Don’t** use high-contrast, 100% opaque borders. This breaks the "Luminous" feel.
- **Don’t** use standard "Material Design" blue for links. Use `secondary` (Teal) or `tertiary` (Indigo).
- **Don’t** use sharp corners. Everything in this system should feel approachable and organic, adhering to the `md` to `xl` roundedness scale.
- **Don’t** use flat grey shadows. Always tint shadows with the background hue to maintain a premium, naturalistic light.