# Design System Specification: Medical Intelligence & High-Tech Authority

## 1. Overview & Creative North Star

**Creative North Star: "The Clinical Luminary"**

This design system transcends the sterile, templated nature of traditional healthcare platforms. It is built upon the concept of **The Clinical Luminary**—an interface that feels both scientifically authoritative and technologically transcendent. We move away from rigid, boxy layouts toward a fluid, "living" environment where data breathes.

By leveraging **intentional asymmetry**, we break the monotony of standard grids. Large-scale typography is paired with expansive white space to create an editorial feel, positioning the platform not just as a tool, but as a prestigious source of health intelligence. The interaction of deep navy depths and luminous glass surfaces mimics the precision of high-end medical imaging and the sophistication of advanced neural networks.

---

## 2. Color Philosophy & Surface Architecture

The palette is anchored in deep, immersive navies (`surface-dim`), punctuated by high-vibrancy "Intelligence Blues" (`primary`) and "Vitality Greens" (`secondary`).

### The "No-Line" Rule
To maintain a premium, bespoke feel, **1px solid borders are prohibited for sectioning.** Boundaries must be defined through tonal shifts or elevation. Use the transition from `surface-container-low` to `surface-container` to define functional zones. A section should never be "boxed in"; it should be "revealed" by its background density.

### Surface Hierarchy & Nesting
Treat the UI as a physical stack of semi-transparent materials. 
- **Layer 0 (Base):** `surface-dim` (#091421) – The foundation.
- **Layer 1 (Sections):** `surface-container-low` (#111C2A) – Large layout blocks.
- **Layer 2 (Functional Units):** `surface-container` (#16202E) – Nested cards and data clusters.
- **Layer 3 (Active/Interactive):** `surface-container-highest` (#2B3544) – Elements requiring immediate focus.

### The "Glass & Gradient" Rule
Floating elements (modals, dropdowns, sticky navs) must utilize **Glassmorphism**. 
- **Surface:** `rgba(255, 255, 255, 0.05)` (on dark) or the provided `rgba(255, 255, 255, 0.72)` (on light).
- **Blur:** `24px` backdrop-filter.
- **Gradients:** Use a subtle linear gradient on primary CTAs from `primary` (#9fcaff) to `primary_container` (#2395f1) at a 135-degree angle to add "soul" and dimension.

---

## 3. Typography: The Editorial Voice

We pair the technical precision of **Inter** with the commanding presence of **Plus Jakarta Sans**.

*   **Display & Headlines (Plus Jakarta Sans):** These are your "Statement" elements. Use `display-lg` (3.5rem) with Extra Bold 800 weights for hero sections. The tight kerning and aggressive weight convey absolute authority.
*   **Titles & Body (Inter):** Inter handles the "Intelligence." Use `title-md` (1.125rem) for sub-headers and `body-lg` (1rem) for analytical text. The neutral, high-legibility nature of Inter balances the "loud" headings, ensuring medical data remains the hero.
*   **Hierarchy as Identity:** Always maintain a significant scale jump between `headline-lg` and `body-lg`. This contrast creates a rhythmic "scanning" experience typical of high-end medical journals.

---

## 4. Elevation & Depth

We achieve depth through **Tonal Layering** rather than heavy shadows.

*   **The Layering Principle:** Place a `surface-container-lowest` card atop a `surface-container-low` section. The subtle delta in hex value creates a "natural lift" that feels architectural rather than digital.
*   **Ambient Shadows:** For floating "intelligence cards," use a tinted shadow: `0px 24px 48px rgba(0, 43, 77, 0.12)`. This uses a blue-tinted base to mimic light refracting through medical-grade glass.
*   **The "Ghost Border" Fallback:** If containment is required for accessibility, use `outline-variant` (#404752) at **15% opacity**. It should be felt, not seen.
*   **Roundedness:** Adhere to the `xl` (3rem) or `lg` (2rem) scale for containers. Large radii suggest safety, approachability, and modern tech hardware.

---

## 5. Component Guidelines

### Buttons: The "Active Pulse"
- **Primary:** Gradient fill (`primary` to `primary_container`), `xl` roundedness (48px height), 24px horizontal padding.
- **Secondary:** Transparent background with a `ghost-border`. On hover, transition to a subtle `surface-bright` fill.
- **States:** On hover, primary buttons should "glow"—increase the ambient shadow spread by 8px.

### Cards & Intelligence Units
- **Forbid Dividers:** Never use lines to separate content within a card. Use `body-sm` labels in `secondary` (#4edea3) and 24px vertical spacing to create grouping.
- **Glass Variation:** Hero cards should use the 24px blur glass effect to sit "above" the data stream.

### Inputs & Fields
- **Field Style:** `surface-container-high` background, no border. On focus, a 2px `primary` bottom-border (not a full box) provides a "clinical" underline effect.
- **Error States:** Use `error` (#ffb4ab) text only. Do not turn the entire box red; keep the architecture clean.

### Specialized Components
- **The "ECG Stream":** SVG wave patterns should be used as background textures in `primary_container` at 5% opacity to reinforce the health-tech context.
- **Staggered Reveals:** Content must not snap into place. Use a `300ms` cubic-bezier (0.22, 1, 0.36, 1) "slide-and-fade" for all card entrances.

---

## 6. Do’s and Don’ts

### Do:
*   **Do** use asymmetrical padding (e.g., 96px top, 128px bottom) to create a sense of movement.
*   **Do** use `secondary_fixed` (#6ffbbe) for "Success" or "Stable" health metrics.
*   **Do** allow typography to overlap background elements or glass layers slightly to enhance depth.

### Don’t:
*   **Don’t** use pure black (#000000) or pure grey. Every dark tone must be tinted with navy (`surface-dim`).
*   **Don’t** use standard 4px or 8px border radii. If it’s not `lg` (32px) or `xl` (48px), it’s not part of this system.
*   **Don’t** use "Drop Shadows" that are grey. Shadows must always be tinted with the background hue to maintain the "Luminary" effect.
*   **Don’t** clutter the screen. If a piece of data isn't vital, use `surface-container-lowest` and `on-surface-variant` text to deprioritize it visually.