---
name: Aorane Business
colors:
  surface: '#f7f9ff'
  surface-dim: '#d7dae0'
  surface-bright: '#f7f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f1f4f9'
  surface-container: '#ebeef4'
  surface-container-high: '#e6e8ee'
  surface-container-highest: '#e0e2e8'
  on-surface: '#181c20'
  on-surface-variant: '#404850'
  inverse-surface: '#2d3135'
  inverse-on-surface: '#eef1f6'
  outline: '#707881'
  outline-variant: '#bfc7d1'
  surface-tint: '#006399'
  primary: '#005d90'
  on-primary: '#ffffff'
  primary-container: '#0077b6'
  on-primary-container: '#f3f7ff'
  inverse-primary: '#94ccff'
  secondary: '#006a60'
  on-secondary: '#ffffff'
  secondary-container: '#86f2e2'
  on-secondary-container: '#006f64'
  tertiary: '#924100'
  on-tertiary: '#ffffff'
  tertiary-container: '#b75508'
  on-tertiary-container: '#fff5f2'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#cde5ff'
  primary-fixed-dim: '#94ccff'
  on-primary-fixed: '#001d32'
  on-primary-fixed-variant: '#004b74'
  secondary-fixed: '#89f5e5'
  secondary-fixed-dim: '#6bd8c9'
  on-secondary-fixed: '#00201c'
  on-secondary-fixed-variant: '#005048'
  tertiary-fixed: '#ffdbc9'
  tertiary-fixed-dim: '#ffb68d'
  on-tertiary-fixed: '#331200'
  on-tertiary-fixed-variant: '#763300'
  background: '#f7f9ff'
  on-background: '#181c20'
  surface-variant: '#e0e2e8'
typography:
  display-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 48px
    fontWeight: '800'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.2'
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: '1.3'
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '500'
    lineHeight: '1.5'
  label-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '600'
    lineHeight: '1'
    letterSpacing: 0.03em
  data-mono:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.4'
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 4px
  gutter: 24px
  margin-page: 40px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 32px
  container-max: 1440px
---

## Brand & Style
The design system embodies "आज़ाद जीवन" (Independent/Free Life), merging cutting-edge 2026 SaaS aesthetics with the human-centric nature of health-tech. It bridges the gap between high-performance financial tools and the softness required for wellness data.

The visual direction combines the depth of **Vision OS** (spatial layers), the precision of **Linear** (functional density), and the polish of **Stripe** (refined typography and motion). 

**Key Visual Identifiers:**
- **The Wordmark:** AORANE in uppercase, tracked tightly for a modern architectural feel.
- **The Subtitle:** "आज़ाद जीवन" set in medium weight, positioned as a subtle anchor below the primary logo.
- **The Icon:** A circular leaf-pulse, representing the intersection of organic life and digital monitoring.
- **Aesthetic Tone:** Light-mode primary, utilizing translucent surfaces to signify transparency and trust in DPDP Act 2023 compliance environments.

## Colors
The palette is rooted in "Aorane Deep Blue" to project institutional stability, supported by "Accent Teal" for health-positive actions and "Warm Accent" for metabolic alerts and high-priority employee wellness triggers.

**Surface Strategy:**
- **Base Layer:** #F7F9FC provides a cool, clinical but approachable foundation.
- **Alt Layer:** #EEF2F7 is used for inset containers or sidebar navigation.
- **Glass Layer:** Pure white with 70% opacity and 20px backdrop blur, creating a sense of weightless intelligence.
- **Compliance Indicators:** Use #1B998B for DPDP Act 2023 verification badges to signal "Safety" and "Authorization."

## Typography
The typographic hierarchy prioritizes rapid scanning of employee health metrics and financial data (INR/GST).

- **Display & Headlines:** Plus Jakarta Sans provides a friendly, rounded geometric feel that softens the "corporate" edge of the SaaS.
- **Body & Functional Text:** Inter ensures maximum legibility at small sizes, particularly for dense CRM tables and compliance documentation.
- **Data & Compliance:** JetBrains Mono is reserved for GST identification numbers, DPDP 2023 hash keys, and currency alignment in billing modules.
- **Localization:** Ensure the Devanagari subtitle "आज़ाद जीवन" maintains optical balance with the Latin wordmark, roughly 40% of the primary wordmark's height.

## Layout & Spacing
The design system utilizes a **12-column fluid grid** for dashboard views, transitioning to a **fixed-center column** (800px) for wellness reports and clinical records.

**Grid Philosophy:**
- **Dynamic Padding:** Containers use 24px internal padding (gutter-sm) to maintain a "breathable" premium feel.
- **Information Density:** While the aesthetic is airy, the data density remains high. Use the 4px base unit to tighten lists and tables, while reserving 32px+ for sectional separation.
- **Currency Alignment:** All ₹ (INR) values in tables must be tabular-numeric aligned to ensure vertical comparison clarity across employee benefit reports.

## Elevation & Depth
This design system rejects heavy shadows in favor of **Layered Glassmorphism** and **Light-source Borders**.

- **Z-Axis Hierarchy:**
    - **Level 0 (Base):** #F7F9FC (Flat).
    - **Level 1 (Cards):** White Surface, 20px Blur, 1px Border (#0077B6 at 8% opacity).
    - **Level 2 (Modals/Dropdowns):** White Surface, 40px Blur, subtle 15% opacity primary shadow (0px 20px 40px).
- **Subtle Borders:** Instead of shadows, use 1px solid borders in a slightly darker tint of the background to define edges. 
- **Focus States:** High-visibility 2px focus rings in #0077B6 with a 2px offset for WCAG AA accessibility.

## Shapes
The shape language is "Mixed-Precision," utilizing varied radii to distinguish between action types and content types.

- **Pill (99px):** Reserved exclusively for primary CTAs and status "Chips" (e.g., Active, Paid, Compliant).
- **Card (20px):** Large radius used for major surface areas to create a soft, welcoming container for sensitive health data.
- **Input (12px):** A tighter radius for functional elements to signal "utility" and "data entry."
- **Iconography:** Contained within circular enclosures to mirror the "Leaf-Pulse" brand icon.

## Components
- **Buttons:**
    - *Primary:* Pill-shaped, #0077B6 background, white text.
    - *Secondary:* Pill-shaped, transparent with 1px border (#0077B6).
    - *Ghost:* Pill-shaped, no border, teal text.
- **Inputs:** 12px rounded, 1px border (#EEF2F7), subtle inner shadow. On focus, border transitions to #0077B6 with the 2px focus ring.
- **Status Chips:** Small pill-shaped badges. "GST Verified" uses Teal (#1B998B), while "Action Required" uses Warm Accent (#FF8C42).
- **Cards:** 20px rounded glass surfaces. Header sections within cards should have a subtle 1px bottom-border separator.
- **Compliance Badges:** Specific 2026-style badges for DPDP Act 2023. These should be 24px height, utilizing the JetBrains Mono font for the "VERIFIED" string.
- **Data Tables:** Row hover state uses #EEF2F7 with 0px blur; headers use Plus Jakarta Sans (Label-sm) for authority.