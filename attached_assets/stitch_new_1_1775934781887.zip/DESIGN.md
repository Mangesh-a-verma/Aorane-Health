# Design System Document: The Radiant Wellness Framework

## 1. Overview & Creative North Star: "The Modern Sanctuary"
This design system moves away from the clinical coldness of traditional health apps, instead embracing the concept of **"The Modern Sanctuary."** It is an editorial approach to wellness that blends the warmth of Indian heritage with the precision of high-end digital craftsmanship.

The experience is defined by **intentional breathability**. We break the "template" look by using exaggerated whitespace, tonal depth instead of hard lines, and an asymmetrical balance that feels organic rather than mechanical. Every element should feel like it is resting on a soft, silk-lined surface—authoritative yet deeply inviting.

---

## 2. Colors: The Saffron & Silk Palette
Our palette utilizes a sophisticated Material-based tonal scale to ensure the vibrant "Saffron" and "Marigold" tones feel premium, not loud.

### Core Tones
*   **Primary (Saffron):** `#a43700` (Main Actions / Brand Identity)
*   **Secondary (Golden Yellow):** `#835500` (Supportive highlights)
*   **Tertiary (Health Green):** `#006a35` (Vitality and Success)
*   **Neutral Surface:** `#fff8f3` (The "Cream" base)

### The "No-Line" Rule
**Explicit Instruction:** Designers are prohibited from using 1px solid borders to section off content. Boundaries must be defined through:
1.  **Background Shifts:** Transitioning from `surface` to `surface-container-low`.
2.  **Tonal Transitions:** Using subtle shifts in the cream gradient to signify a new content area.
3.  **Negative Space:** Using the spacing scale to create mental groupings.

### Surface Hierarchy & Nesting
Treat the UI as physical layers of "fine paper."
*   **Base:** `surface` (#fff8f3)
*   **Sectioning:** `surface-container-low` (#f9f2ed) for large background blocks.
*   **Interactive Cards:** `surface-container-lowest` (#ffffff) to provide a "lifted" feel.

### The "Glass & Gradient" Rule
To elevate beyond "standard" flat design:
*   **Floating Elements:** Use `surface-container-lowest` with 80% opacity and a 16px `backdrop-blur`.
*   **Signature Gradients:** For Hero sections and Primary CTAs, use a linear gradient: `primary` (#a43700) to `primary-container` (#c94c13) at a 135-degree angle. This adds "soul" and depth.

---

## 3. Typography: The Editorial Voice
We use **Inter** not as a utility font, but as a bold, editorial statement.

*   **Display (lg/md/sm):** 700 Bold. Used for high-impact motivation or vital stats.
*   **Headline (lg/md/sm):** 700 Bold. The primary voice for screen titles.
*   **Title (lg/md/sm):** 600 SemiBold. Used for card headers and section subtitles.
*   **Body (lg/md/sm):** 400 Regular. Optimized for readability in wellness articles and logs.
*   **Label (md/sm):** 600 SemiBold. Reserved for micro-copy and functional tags.

**Hierarchy Strategy:** Create high contrast by pairing `display-md` headlines with `body-sm` metadata. This "big and small" approach mimics premium health journals.

---

## 4. Elevation & Depth: Tonal Layering
We avoid the "card-on-gray" cliché. Depth is achieved through light and warmth.

*   **The Layering Principle:** Place a `surface-container-lowest` (pure white) card on a `surface-container-low` (pale cream) background. This creates a natural, soft lift without a single line of CSS border.
*   **Ambient Shadows:** For "floating" elements (FABs, Modals), use a shadow with a 24px blur, 0px Y-offset, and 6% opacity. The shadow color must be `on-surface-variant` (#594139)—a warm brown—never pure black.
*   **The "Ghost Border" Fallback:** If a container needs more definition, use `outline-variant` (#e0bfb4) at **15% opacity**. This creates a "suggestion" of a border that vanishes into the background.
*   **Interactive Bounce:** All touch targets must use a spring-based transition (0.4s, damping 0.7). Elements should feel "pliant" and responsive to the touch.

---

## 5. Components

### Buttons
*   **Primary:** Gradient fill (`primary` to `primary-container`), `on-primary` text, 20px (`xl`) border radius.
*   **Secondary:** `surface-container-lowest` fill with a "Ghost Border."
*   **Tertiary:** Ghost button using `primary` text and 600 SemiBold weight.

### Cards (The "Wellness Module")
*   **Construction:** `surface-container-lowest` fill, 20px radius, no visible border, subtle ambient warm shadow.
*   **Content:** No dividers. Separate header from body using `16px` vertical white space.

### Chips (Selection & Filter)
*   **State:** Unselected chips use `surface-container-high` with no border. Selected chips use `primary-fixed` (#ffdbcf) with `on-primary-fixed` (#380d00) text.

### Input Fields
*   **Style:** Minimalist. Underline style is forbidden. Use a soft-filled container (`surface-container-highest`) with a 12px radius. On focus, the container transitions to `surface-container-lowest` with a 1px `primary` ghost border (20% opacity).

### Health-Specific Components
*   **Vitality Ring:** A custom circular progress component using `tertiary` (Health Green) for progress and `tertiary-container` at 20% opacity for the track.
*   **The Medicine Drawer:** A bottom sheet using Glassmorphism (`surface` at 90% + blur) to overlay current medication schedules without losing the context of the main screen.

---

## 6. Do's and Don'ts

### Do
*   **Do** use asymmetrical margins. A 24px left margin and 16px right margin on certain text blocks creates a sophisticated editorial rhythm.
*   **Do** use Lucide-style icons with a consistent 2px stroke. Icons should be `primary` or `on-surface-variant`.
*   **Do** embrace the cream background. Pure white should only be used for "floating" interactive elements.

### Don't
*   **Don't** use a standard 1px #EEEEEE divider. Use an 8px vertical gap or a subtle color shift.
*   **Don't** use high-contrast drop shadows. If it looks like it’s "hovering" more than 2mm off the screen, it’s too heavy.
*   **Don't** use "Alert Red" for errors. Use the `error` token (#ba1a1a) which is tuned to sit harmoniously within the warm palette.

---

## 7. Spacing & Grid
*   **Base Unit:** 4px.
*   **Gutter:** 16px or 20px (consistent with border radius).
*   **Vertical Rhythm:** Use 32px or 48px between major sections to emphasize the "Sanctuary" feel—giving the user's eyes room to rest.