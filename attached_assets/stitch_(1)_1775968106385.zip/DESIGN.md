# Design System Strategy: AORANE Health-Tech CRM

## 1. Overview & Creative North Star
**Creative North Star: "The Clinical Sanctuary"**

This design system moves away from the cluttered, high-density "dashboard" aesthetic. Instead, it embraces a high-end editorial approach tailored for high-stakes health technology. We treat the interface as a "Sanctuary"—a space that feels breathable, authoritative, and impossibly smooth. 

By leveraging intentional asymmetry, oversized typography for key metrics, and a "Glass-on-Void" depth model, we break the traditional CRM grid. We are not building a table; we are curating a medical intelligence experience. The layout prioritizes "breathing room" (negative space) to reduce cognitive load, ensuring that when an AI-driven insight appears, it carries the weight of a premium consultation.

---

## 2. Colors & Tonal Depth
Our palette is rooted in a deep, nocturnal foundation punctuated by "Medicinal" accents that evoke precision and life.

### The "No-Line" Rule
Standard 1px borders are strictly prohibited for structural sectioning. To separate content, designers must use **Tonal Shift** (e.g., placing a `surface-container-high` card against a `surface-dim` background). Boundaries are felt, not seen.

### Surface Hierarchy & Nesting
Treat the UI as a physical stack of semi-translucent materials. 
- **Base Layer:** `surface-container-lowest` (#090e1c) for the global background.
- **Content Blocks:** `surface-container` (#1a1f2f) to define major work areas.
- **Actionable Elements:** `surface-container-highest` (#2f3445) for floating cards or interactive modals.

### The "Glass & Gradient" Rule
For AI-driven insights or "High-Confidence" notifications, use **Glassmorphism**:
- **Fill:** `rgba(255, 255, 255, 0.04)`
- **Blur:** `backdrop-filter: blur(20px)`
- **Border:** `1px solid rgba(255, 255, 255, 0.08)` (The only exception to the No-Line rule).

### Signature Textures
Main CTAs and Hero Charts should utilize a **Linear Gradient** transition from `primary` (#94ccff) to `primary-container` (#0077b6) at a 135-degree angle. This adds a "lithographic" quality to the digital interface, preventing the "flat-UI" fatigue.

---

## 3. Typography
We utilize **Inter** for its clinical legibility and **JetBrains Mono** for technical precision.

- **Display Scale (The Authority):** Use `display-lg` (3.5rem) for singular, critical health metrics (e.g., Patient Heart Rate). This creates a focal point that demands attention.
- **Headline & Title:** `headline-md` and `title-lg` should be set with tight tracking (-0.02em) to feel like a high-end medical journal.
- **Technical IDs:** All Patient IDs, Case Numbers, and Code Snippets must use `JetBrains Mono`. This stylistic shift signals to the user that they are looking at raw, un-editable data.
- **Hierarchy through Weight:** Use `font-medium` (500) for body text on dark surfaces to prevent "ink bleed" and maintain readability.

---

## 4. Elevation & Depth
Depth in this system is achieved through **Tonal Layering**, not shadows.

- **Layering Principle:** To "lift" a component, move it one step up the surface scale. A `surface-container-low` object sitting on `surface-dim` creates a natural, soft-touch elevation.
- **Ambient Shadows:** Only use shadows for "Temporary Overlays" (Modals/Popovers). Shadows must be `on-surface` color at 6% opacity with a `24px` blur. Avoid black shadows; they muddy the dark-mode colors.
- **The Ghost Border:** If a form field or container needs definition against a similar background, use the `outline-variant` token at 15% opacity. It should be a "whisper" of a line.

---

## 5. Components & Interaction

### Buttons
- **Primary:** Gradient fill (Primary to Primary-Container), `rounded-md`, with a `scale-1015` hover effect.
- **Secondary:** Transparent background with a `Ghost Border`.
- **Active State:** All buttons must use `scale-97` on click to provide tactile feedback.

### Cards & Lists
- **The "No-Divider" Rule:** Explicitly forbid horizontal rules `<hr />`. Use `1.5rem` of vertical whitespace or a background shift to `surface-container-low` to separate list items.
- **Nesting:** Cards should have a `rounded-lg` (1rem) corner radius to feel approachable.

### Input Fields
- **Default State:** `surface-container-high` background, no border.
- **Focus State:** `1px solid primary`. The background should shift slightly brighter to indicate readiness.

### AI Insight Chips
- Use `secondary` (#6bd8c9) with a 10% opacity background and a solid `secondary` label. These should "glow" subtly using a `0 0 12px` spread of the same color.

---

## 6. Do’s and Don’ts

### Do
- **Use Asymmetry:** Place secondary actions off-center to create a sophisticated, editorial flow.
- **Embrace "Dead" Space:** Allow key metrics to sit in large empty containers to increase their perceived importance.
- **Prioritize Motion:** Use smooth transitions (200ms ease-in-out) for all state changes.

### Don’t
- **Don’t use 100% White:** Never use `#FFFFFF` for text in dark mode. Use `on-surface` (#dee1f7) or `on-surface-variant` (#bfc7d1) to prevent eye strain.
- **Don’t use Grid Lines:** Avoid visible table borders. Use staggered background rows (Zebra striping using `surface-container-low`) if a table is absolutely necessary.
- **Don’t Over-Shadow:** If you need more than three layers of depth, you are overcomplicating the layout. Flatten the hierarchy.

### Tech Stack Implementation Note
Use **Shadcn UI** primitives but strip all default border classes. Replace them with Tailwind’s `bg-surface-container` and `backdrop-blur` utilities to align with this system's "Sanctuary" aesthetic.